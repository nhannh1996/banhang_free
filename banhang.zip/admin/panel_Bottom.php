<br>
<table border="1" bordercolor="0069A8" style="border-collapse: collapse" width="100%" cellspacing="0" cellpadding="0">
	<tr>
		<td height="20" align="center" bgcolor="#0069A8" class="midtitle">
		<font style="font-size: 8.5pt" face="Tahoma">Copyright 
		2013 @ Powered by </font>
		<a href="http://thietkewebx.net/"><font color="#ffffff" style="font-size: 8.5pt" face="Tahoma">ThietkewebX.net</font></a></td>
	</tr>
</table>
