<table border="1" bordercolor="0069A8" style="border-collapse: collapse" width="100%" cellspacing="0" cellpadding="0">
	<tr>
		<td height="40" bgcolor="#0069A8" align="left">
			<a href="./"><font color="#FFFFFF"><span style="font-weight: 700">Control Panel - VietNext Co. </span></font></a>
		</td>
	</tr>
	<tr><td height="2"></td></tr>
</table>
