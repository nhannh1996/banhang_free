<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Insert title here</title>
<link rel="stylesheet" href="css.css" media="screen" type="text/css"></link>
<script type="text/javascript" src="js.js"></script>
</head>
<body>

<div id="dhtmlgoodies_menu" style="visibility: hidden;">
	<ul>
		<li><a href="#">New scripts</a>
			<ul>
				<li><a href="#">Slide out menu</a></li>
				<li><a href="#">Content organizer</a>
					<ul>
						<li><a href="#">Item #1</a></li>
						<li><a href="#">Item #2</a></li>
					</ul>
				</li>
				<li><a href="#">Slide in pane</a></li>
			</ul>
		</li>
		
		<li><a href="#">New scripts</a>
		</li>
	</ul>
</div>

</body>
</html>