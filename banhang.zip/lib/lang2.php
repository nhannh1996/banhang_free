<?php define('_HOME'            ,'Home');
define('_INTRO'           ,'About us');
define('_INTRO_'          ,'ABOUT US');
define('_SERVICE'		  ,'Service');
define('_NEWSEVENT'		  ,'News & Event');
define('_CONTACT'         ,'Contact us');
//----------------------------Danh mục sp-----------------------------------
define('_CATEGORY'         ,'CATEGORY');
define('_SUPPORTONLINE'    ,'ONLINE SUPPORT');
define('_MEMBER'           ,'MEMBER');
define('_MEMBER_'           ,'Member');
define('_INFORMATION'      ,'INFORMATION');
define('_TOTAL'            ,'Total Visitors');
define('_LINKWEBSITE'      ,'Link website');
///----------------------------------SP-------------------------------------
define('_PRODUCTNEW'	   ,'NEW PRODUCT');
define('_NEWS'	 		   ,'NEWS');
define('_ADVERTISE'	 	   ,'ADVERTISE');
define('_BEST_SELLING'	   ,'PRODUCT BEST SELLING');
//--------------------------------------------------------------------------
define('_GOLD'            ,'SJC Gold Rate');
define('_FOREX'           ,'VCB Rate Exchange');

define('_SEARCH'          ,'SEARCH');
define('_DETAIL'		  ,'Detail');
define('_SEARCH'          ,'SEARCH');
define('_UID'             ,'Username');
define('_PWD'             ,'Password');
define('_REGISTRY'        ,'Registry');
define('_LOGIN'           ,'Login');
define('_LOGOUT'          ,'Logout');
define('_FORGOTPASS'      ,'Forgot password');
define('_ACCOUNT'         ,'My account');

//---------------------------------------------------------------------------

?>
